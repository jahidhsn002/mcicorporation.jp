<?php $__env->startSection('content'); ?>
    <div class="container page_single">
        <div class="columns">
            <div class="column is-10 is-offset-1">
                <div class="columns my-0 is-multiline">
                    <div class="column is-6">
                        <?php if($vehicle->thumbnail): ?>
                            <?php $__currentLoopData = json_decode($vehicle->thumbnail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <figure>
                                <img src="<?php echo e(asset($link)); ?>" data-action="zoom" class="joomable">
                            </figure>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <img src="<?php echo e(asset('img/car_1.jpg')); ?>">
                        <?php endif; ?>
                        <div class="gullery_thumbnail columns my-0 is-multiline">
                            <?php if($vehicle->gallery): ?>
                                <?php $__currentLoopData = json_decode($vehicle->gallery); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <figure class="column is-3">
                                    <img src="<?php echo e(asset($link)); ?>" data-action="zoom" class="joomable">
                                </figure>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <figure class="column is-3">
                                    <img src="<?php echo e(asset('img/car_1.jpg')); ?>">
                                </figure>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="column is-6">
                        <h3 class="title is-4"><?php echo e($vehicle->name); ?></h3>
                        <div class="price columns mb-0">
                            <div class="column is-8">
                                <div class="box mb-0 pa-10 has-text-right">
                                    <?php if($vehicle->actual_price): ?>
                                        <h4 class="title is-5 my-5">
                                            Original Price: <del><?php echo e($vehicle->actual_price); ?></del> <br/>
                                        </h4>
                                    <?php endif; ?>
                                    <h4 class="title is-4 my-5">
                                        Current price: <span class="has-text-success"><?php echo e($vehicle->price); ?></span> <br/>
                                    </h4>
                                    <?php if($vehicle->actual_price): ?>
                                    <h4 class="title is-5 my-5">
                                        You Save: <span class="has-text-danger"><?php echo e($vehicle->actual_price - $vehicle->price); ?></span>
                                    </h4>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="column">
                                <?php if(Auth::check()): ?>
                                    <?php if(Auth::user()->is_admin): ?>
                                    <a class="button is-warning is-small mb-2" style="width:100%" href="<?php echo e(route('save_vehicle', ['id'=>$vehicle->id])); ?>">Edit</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <a href="<?php echo e(route('favorite_save', ['vehicle_id' => $vehicle->id])); ?>" class="button is-warning mb-2" style="width:100%">Favorite</a> <br/>
                                <button class="button is-warning" style="width:100%">Print</button>
                            </div>
                        </div>
                        <div class="has-text-left lg_button mb-20">
                            <app-model>
                                    <span slot="button">
                                        Get a price quote now
                                    </span>
                                    <inquery-form
                                        ajax_inquery_url = "<?php echo e(route('ajax_inquery')); ?>"
                                        <?php if(isset($vehicle->id)): ?> vehicle_id="<?php echo e($vehicle->id); ?>" <?php endif; ?>
                                        <?php if(isset($_REQUEST['country_id'])): ?> country_id="<?php echo e($_REQUEST['country_id']); ?>" <?php endif; ?>
                                        <?php if(isset($_REQUEST['port_id'])): ?> port_id="<?php echo e($_REQUEST['port_id']); ?>" <?php endif; ?>

                                        <?php if(isset($_REQUEST['insurance'])): ?> insurance="<?php echo e($_REQUEST['insurance']); ?>" <?php endif; ?>
                                        <?php if(isset($_REQUEST['inspection'])): ?> inspection="<?php echo e($_REQUEST['inspection']); ?>" <?php endif; ?>
                                        <?php if(isset($_REQUEST['certificate'])): ?> certificate="<?php echo e($_REQUEST['certificate']); ?>" <?php endif; ?>
                                        <?php if(isset($_REQUEST['warranty'])): ?> warranty="<?php echo e($_REQUEST['warranty']); ?>" <?php endif; ?>
                                        
                                    ></inquery-form>
                                </app-model>
                        </div>
                        <div class="card">
                            <header class="card-header">
                                <p class="card-header-title is-5 title">Specs</p>
                            </header>
                            <div class="card-content pa-0">
                                <div class="columns is-gapless">
                                    <div class="column is-6 pa-0">
                                        <table class="table is-striped mb-5" width="100%">
                                            <tr>
                                                <th>Ref No</th>
                                                <td><?php echo e($vehicle->ref_no); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Engine Size</th>
                                                <td><?php echo e($vehicle->engine); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Model Code</th>
                                                <td><?php echo e($vehicle->model_code); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Mileage</th>
                                                <td><?php echo e($vehicle->mileage); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Chassis</th>
                                                <td><?php echo e($vehicle->chassis); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Engine Code</th>
                                                <td><?php echo e($vehicle->engine_code); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Seats</th>
                                                <td><?php echo e($vehicle->seats); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Dors</th>
                                                <td><?php echo e($vehicle->dors); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Simension</th>
                                                <td><?php echo e($vehicle->dimension); ?></td>
                                            </tr>
                                            <tr>
                                                <th>M3</th>
                                                <td><?php echo e($vehicle->m3); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Weight</th>
                                                <td><?php echo e($vehicle->weight); ?></td>
                                            </tr>
                                            <tr>
                                                <th class="has-text-success">Manufacture <br/> Year/month</th>
                                                <td><?php echo e($vehicle->manufacture); ?></td>
                                            </tr>
                                            <tr>
                                                <th class="has-text-danger">Registration <br/> Year/month</th>
                                                <td><?php echo e($vehicle->registration); ?></td>
                                            </tr>
                                        </table>
                                        <div class="pa-5">
                                            <small>
                                            <small class="has-text-success">
                                                * [Manufacture Year/month] is provided by database provider. 
                                                BE FORWARD shall not be responsible for any loss, damages
                                                and troubles caused by this information.
                                            </small>
                                            </small>
                                            <br>
                                            <small>
                                            <small class="has-text-danger">
                                                * [Registration Year/month] is a registration date in Japan.
                                            </small>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="column is-6 pa-0">
                                        <table class="table is-striped mb-5" width="100%">
                                            <?php $__currentLoopData = $vehicle->taxonomies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax_meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th><?php echo e($tax_meta->taxonomy->name); ?></th>
                                                <td><?php echo e($tax_meta->name); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card feature mt-10">
                            <h3 class="title is-5 px-10 pt-15 pb-0 mb-0">Standard features</h3>
                            <div class="card-content">
                                <div class="columns is-multiline is-gapless">
                                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="column is-3">
                                        <div class="pa-10 box ma-2 is-radiusless <?php echo e(in_array($feat->id, $feature_selected)?'selected':''); ?>"><?php echo e($feat->name); ?></div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-6 is-offset-3">

                    <form action="<?php echo e(route('inquary_email')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="post">

                        <inquery-form-2

                            ajax_inquery_url = "<?php echo e(route('ajax_inquery')); ?>"
                            <?php if(isset($vehicle->id)): ?> vehicle_id="<?php echo e($vehicle->id); ?>" <?php endif; ?>
                            <?php if(isset($_REQUEST['country_id'])): ?> country_id="<?php echo e($_REQUEST['country_id']); ?>" <?php endif; ?>
                            <?php if(isset($_REQUEST['port_id'])): ?> port_id="<?php echo e($_REQUEST['port_id']); ?>" <?php endif; ?>

                            <?php if(isset($_REQUEST['insurance'])): ?> insurance="<?php echo e($_REQUEST['insurance']); ?>" <?php endif; ?>
                            <?php if(isset($_REQUEST['inspection'])): ?> inspection="<?php echo e($_REQUEST['inspection']); ?>" <?php endif; ?>
                            <?php if(isset($_REQUEST['certificate'])): ?> certificate="<?php echo e($_REQUEST['certificate']); ?>" <?php endif; ?>
                            <?php if(isset($_REQUEST['warranty'])): ?> warranty="<?php echo e($_REQUEST['warranty']); ?>" <?php endif; ?>
                            
                        ></inquery-form-2>

                    </form>

                    <div class="card mt-15">
                        <header class="card-header">
                            <p class="card-header-title">HOW TO GET A PROFORMA INVOICE</p>
                        </header>
                        <div class="card-content">
                            <h5 class="title is-6 mb-10 mt-0">To get Proforma Invoice, please do the followings:</h5>
                            <div class="pl-15">
                                <ol>
                                    <li>Fill out the required fields above and click the Inquiry button.</li>
                                    <li>You will receive a quotation from BE FORWARD via email.</li>
                                    <li>Reply to the email if you accept the quotation.</li>
                                    <li>We will issue a Proforma Invoice once you completed the steps above.</li>
                                </ol>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>