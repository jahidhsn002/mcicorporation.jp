<!-- Step 01 -->
<?php if(isset($_REQUEST['inquery'])): ?>
    <div class="card" id="step">
        <header class="card-header">
            <p class="card-header-title">Step 2. CHOOSE YOUR DELIVERY OPTIONS</p>
        </header>
        <div class="card-content">
            <form action="<?php echo e(route('inquary_email')); ?>#sep-1" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="patch">
                <input type="hidden" name="vehicle_id" value="<?php echo e($vehicle->id); ?>">
                <div class="field">
                    <label class="label">Choose Final Country*</label>
                    <div class="control">
                        <div class="select">
                          <select name="country_id">
                            <option>Select</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($country->id); ?>"
                                <?php if(isset($_REQUEST['country_id'])): ?>
                                    <?php if($_REQUEST['country_id']==$country->id): ?>
                                        selected
                                    <?php endif; ?>
                                <?php endif; ?>
                            ><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                    </div>
                </div>
                <div class="field">
                    <table class="table" width="100%">
                        <tr>
                            <th>Choose</th>
                            <th>Port</th>
                            <th>Destination</th>
                            <th>Cost</th>
                            <th>Total</th>
                        </tr>
                        <?php $__currentLoopData = $ports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="control">
                                    <label class="radio">
                                      <input value="<?php echo e($port->id); ?>" type="radio" name="port_id" 
                                        <?php if(isset($_REQUEST['port_id'])): ?>
                                            <?php if($_REQUEST['port_id']==$port->id): ?>
                                                checked
                                            <?php endif; ?>
                                        <?php endif; ?>
                                      >
                                    </label>
                                </div>
                            </td>
                            <td><?php echo e($port->name); ?></td>
                            <td><?php echo e($port->name); ?> (port)</td>
                            <td><?php echo e($port->insurance+$port->inspection+$port->certificate+$port->warranty); ?></td>
                            <td><?php echo e($vehicle->price+$port->insurance+$port->inspection+$port->certificate+$port->warranty); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <div class="field">
                    <button class="button is-dark px-50" type="submit">Get Quote</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mt-15">
        <header class="card-header">
            <p class="card-header-title">Step 3. YOUR DETAILS</p>
        </header>
        <div class="card-content">
            <div class="columns">
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Name*</label>
                        <div class="control">
                            <input class="input" type="text" name="name" 
                                <?php if(Auth::check()): ?>
                                value="<?php echo e(Auth::user()->name); ?>"
                                <?php endif; ?>
                            >
                        </div>
                    </div>
                    <div class="field">
                        <label class="label">Email*</label>
                        <div class="control">
                            <input class="input" type="email" name="email" 
                                <?php if(Auth::check()): ?>
                                value="<?php echo e(Auth::user()->email); ?>"
                                <?php endif; ?>
                            >
                        </div>
                    </div>
                    <div class="field">
                        <label class="label">Phone*</label>
                        <div class="control">
                            <input class="input" type="text" name="phone" 
                                <?php if(Auth::check()): ?>
                                value="<?php echo e(Auth::user()->phone); ?>"
                                <?php endif; ?>
                            >
                        </div>
                    </div>
                </div>
                <div class="column is-6">
                    <div class="field">
                        <label class="label">City*</label>
                        <div class="control">
                            <input class="input" type="text" name="city" 
                                <?php if(Auth::check()): ?>
                                value="<?php echo e(Auth::user()->city); ?>"
                                <?php endif; ?>
                            >
                        </div>
                    </div>
                    <div class="field">
                        <label class="label">Address*</label>
                        <div class="control">
                            <input class="input" type="text" name="address" 
                                <?php if(Auth::check()): ?>
                                value="<?php echo e(Auth::user()->address); ?>"
                                <?php endif; ?>
                            >
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php endif; ?>