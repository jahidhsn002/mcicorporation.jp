<?php $__env->startSection('content'); ?>
    <div class="container mb-50">
        <div class="columns is- is-marginless is-centered">
            <div class="column is-2">
                <?php echo $__env->make('layouts.left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="column is-8">
                <div class="columns is-multiline">

                    <form action="<?php echo e(route('archive')); ?>" method="GET">
                    
                        <?php echo $__env->make('layouts.home_search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    </form>

                    <section class="blog_post column is-12">
                        <div class="columns">
                            <div class="column is-3">
                                <a href="#">
                                    <img src="<?php echo e(asset('img/page_banner.jpg')); ?>" width="100%"> <br/>
                                    <span>These are global default options</span>
                                </a>
                            </div>
                            <div class="column is-3">
                                <a href="#">
                                    <img src="<?php echo e(asset('img/page_banner.jpg')); ?>" width="100%"> <br/>
                                    <span>These are global default options</span>
                                </a>
                            </div>
                            <div class="column is-3">
                                <a href="#">
                                    <img src="<?php echo e(asset('img/page_banner.jpg')); ?>" width="100%"> <br/>
                                    <span>These are global default options</span>
                                </a>
                            </div>
                            <div class="column is-3">
                                <a href="#">
                                    <img src="<?php echo e(asset('img/page_banner.jpg')); ?>" width="100%"> <br/>
                                    <span>These are global default options</span>
                                </a>
                            </div>
                        </div>
                    </section>

                    <div class="column is-12">
                        <h4 class="title is-4 mb-5">New Arrival</h2>
                        <div class="a-line">
                            <div></div>
                        </div>
                    </div>

                    <?php $__currentLoopData = $new_arrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="column is-2">
                        <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                            <?php if($vehicle->thumbnail): ?>
                                <?php $__currentLoopData = json_decode($vehicle->thumbnail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <figure>
                                    <img src="<?php echo e(asset($link)); ?>" width="100%">
                                </figure>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/car.jpg')); ?>" width="100%">
                            <?php endif; ?>
                            <h3 class="title is-5 ma-0"><?php echo e($vehicle->name); ?></h3>
                            <div>Vehicle Price:</div>
                            <h3 class="title is-6 ma-0"><?php echo e($vehicle->price); ?></h3>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="column is-12">
                        <h4 class="title is-4 mb-5">Best Deals</h2>
                        <div class="a-line">
                            <div></div>
                        </div>
                    </div>

                    <?php $__currentLoopData = $best_deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="column is-2">
                        <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                            <?php if($vehicle->thumbnail): ?>
                                <?php $__currentLoopData = json_decode($vehicle->thumbnail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <figure>
                                    <img src="<?php echo e(asset($link)); ?>" width="100%">
                                </figure>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/car.jpg')); ?>" width="100%">
                            <?php endif; ?>
                            <h3 class="title is-5 ma-0"><?php echo e($vehicle->name); ?></h3>
                            <div>Vehicle Price:</div>
                            <h3 class="title is-6 ma-0"><?php echo e($vehicle->price); ?></h3>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="column is-12">
                        <h4 class="title is-4 mb-5">Premium Class</h2>
                        <div class="a-line">
                            <div></div>
                        </div>
                    </div>

                    <?php $__currentLoopData = $premium_class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="column is-2">
                        <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                            <?php if($vehicle->thumbnail): ?>
                                <?php $__currentLoopData = json_decode($vehicle->thumbnail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <figure>
                                    <img src="<?php echo e(asset($link)); ?>" width="100%">
                                </figure>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/car.jpg')); ?>" width="100%">
                            <?php endif; ?>
                            <h3 class="title is-5 ma-0"><?php echo e($vehicle->name); ?></h3>
                            <div>Vehicle Price:</div>
                            <h3 class="title is-6 ma-0"><?php echo e($vehicle->price); ?></h3>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="column is-12">
                        <h4 class="title is-4 mb-5">Best by types</h2>
                        <div class="a-line">
                            <div></div>
                        </div>
                    </div>

                    <?php $__currentLoopData = $sidebar->{'body-type'}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="column is-4">
                        <div class="columns">
                            <div class="column is-4">
                                <a href="<?php echo e(route('archive', ['taxonomy[]' => $type->id])); ?>">
                                    <?php if($type->logo): ?>
                                        <?php $__currentLoopData = json_decode($type->logo); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <figure>
                                            <img src="<?php echo e(asset($link)); ?>" width="100%">
                                        </figure>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('img/body_type_logo.jpg')); ?>" width="100%">
                                    <?php endif; ?>
                                    <h3 class="title is-6 ma-0 has-text-centered"><?php echo e($type->name); ?></h3>
                                </a>
                            </div>
                            <div class="column is-8">
                                <?php if($type->vehicles): ?>
                                    <?php $__currentLoopData = $type->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <h3 class="title is-6 my-10"> - <?php echo e($vehicle->name); ?></h3>
                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="column is-12">
                        <h4 class="title is-4 mb-5">Popular Used Cars</h2>
                        <div class="a-line">
                            <div></div>
                        </div>
                    </div>

                    <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="column is-4 py-5">
                        <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                            <h3 class="title is-6 ma-0"> <i class="fa fa-arrow-right"></i> <?php echo e($vehicle->name); ?></h3>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <div class="column is-2">
                <?php echo $__env->make('layouts.right_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>