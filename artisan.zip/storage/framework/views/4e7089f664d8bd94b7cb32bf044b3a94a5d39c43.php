<nav class="navbar is-dark has-shadow main_navbar">
    <div class="container">
        <div class="navbar-brand">
            <a class="navbar-item" href="https://bulma.io">
              <img src="img/logo.png" width="112" height="28">
            </a>
            <div class="navbar-burger burger" data-target="navMenu">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>

        <div class="navbar-menu" id="navMenu">
            <div class="navbar-start">
                <div class="navbar-item has-dropdown is-hoverable is-mega">
                    <a class="navbar-link" href="#">
                        <div class="has-text-centered">
                            <i class="fa fa-car fa-3x"></i>
                            <br>Browse Stocks
                        </div>
                    </a>
                    <div class="navbar-dropdown">
                        <div class="container is-fluid">
                            <div class="columns">
                                <div class="column">
                                    <div class="saperater">
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <h5 class="title is-6 pl-10 py-0 my-10">Sub Menu Title</h5>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                    </div>
                                </div>
                                <div class="column">
                                    <div class="saperater">
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                    </div>
                                </div>
                                <div class="column">
                                    <div class="saperater">
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <h5 class="title is-6 pl-10 py-0 my-10">Sub Menu Title</h5>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                    </div>
                                </div>
                                <div class="column">
                                    <div class="saperater">
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                        <a class="navbar-item py-2" href="#">Browse all cars</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="navbar-item has-dropdown is-hoverable is-mega">
                    <a class="navbar-link " href="#">
                        <div class="has-text-centered">
                            <i class="fa fa-mobile fa-3x"></i>
                            <br>Electronics
                        </div>
                    </a>
                </div>
                <div class="navbar-item has-dropdown is-hoverable is-mega">
                    <a class="navbar-link " href="#">
                        <div class="has-text-centered">
                            <i class="fa fa-info-circle fa-3x"></i>
                            <br>About &amp; Support
                        </div>
                    </a>
                </div>
                <div class="navbar-item has-dropdown is-hoverable is-mega">
                    <a class="navbar-link " href="#">
                        <div class="has-text-centered">
                            <i class="fa fa-globe fa-3x"></i>
                            <br>Local Service
                        </div>
                    </a>
                </div>
                <div class="navbar-item has-dropdown is-hoverable is-mega">
                    <a class="navbar-link " href="#">
                        <div class="has-text-left">
                            Customer Reviews <br>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i> 4.7
                            <br>Read 245877 Reviews
                        </div>
                    </a>
                </div>
            </div>

            <div class="navbar-end">
                <div class="navbar-item">
                    <div class="has-text-right">
                        New customer? Create account <br>
                        <a class="button is-warning is-small px-50" href="#">Log In</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>