<?php $__env->startSection('content'); ?>
<div class="pa-50">	
	<h3 class="title is-4 mb-5">Favorites</h3>
	<div>
		List of your favorite vehicles. You will be notified by email when vehicles' status changes to "Marked Down Prices".
		<hr class="mt-5 mb-30" />
	</div>
	<div class="mt-15">
		<?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e(route('favorite_save', ['vehicle_id' => $vehicle->id])); ?>" class="delete is-pulled-right"></a>
    	<div class="columns">
    		<div class="column is-2">
    			<?php if($vehicle->thumbnail): ?>
                    <?php $__currentLoopData = json_decode($vehicle->thumbnail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure>
                        <img src="<?php echo e(asset($link)); ?>">
                    </figure>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <img src="<?php echo e(asset('img/car_1.jpg')); ?>">
                <?php endif; ?>
			</div>
			<div class="column is-10">
				<div class="columns mb-5">
		    		<div class="column is-6 py-2">
		    			<h2 class="title is-4 mb-0"> <?php echo e($vehicle->name); ?> </h2>
					</div>
					<div class="column is-6 py-2 has-text-right">
						<h3 class="title is-5 mb-0"> Vehicle Price: <?php echo e($vehicle->price); ?> <br/>
							<small>You Save: $378 (15%)</small>
						</h3>
					</div>
				</div>
    			<div class="columns">
		    		<div class="column is-4 py-5">
		    			<table class="table is-bordered mb-0" width="100%">
		    				<tr>
		    					<td>Ref No.</td>
		    					<td> <?php echo e($vehicle->ref_no); ?> </td>
		    				</tr>
		    				<tr>
		    					<td>Price</td>
		    					<td> <?php echo e($vehicle->price); ?> </td>
		    				</tr>
		    				<tr>
		    					<td>Model Code</td>
		    					<td> <?php echo e($vehicle->model_code); ?> </td>
		    				</tr>
		    				<tr>
		    					<td>Manufacturine</td>
		    					<td> <?php echo e($vehicle->manufacture); ?> </td>
		    				</tr>
		    			</table>
					</div>
					<div class="column is-4 py-5">
						<table class="table is-bordered mb-0" width="100%">
		    				<tr>
		    					<td>Engine</td>
		    					<td> <?php echo e($vehicle->engine); ?> </td>
		    				</tr>
		    				<tr>
		    					<td>Mileage</td>
		    					<td> <?php echo e($vehicle->mileage); ?> </td>
		    				</tr>
		    				<tr>
		    					<td>Seats</td>
		    					<td> <?php echo e($vehicle->seats); ?> </td>
		    				</tr>
		    				<tr>
		    					<td>Dimension</td>
		    					<td> <?php echo e($vehicle->dimension); ?> </td>
		    				</tr>
		    			</table>
					</div>
					<div class="column is-4 has-text-right">
						<button class="button is-large is-warning has-text-uppercase px-50 mb-10"> Inquary </button>
					</div>
				</div>
			</div>
	    </div>
		<hr class="mt-0 mb-30" />
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="has-text-centered">
    	<a href="#">Back to Dashboard</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>