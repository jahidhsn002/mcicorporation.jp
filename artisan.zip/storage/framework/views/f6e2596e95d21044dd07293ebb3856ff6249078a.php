<section class="search_box box column is-12 mt-15 mb-0">
    <h5 class="title is-5 mb-5">SEARCH FOR CARS</h5>
    <div class="b-line">
        <div></div>
    </div>
    <div class="columns pt-10">
        <div class="column is-10">
            <div class="field is-horizontal">
                <div class="field-label is-normal">
                    <label class="label">Search By Keyword</label>
                </div>
                <div class="field-body">
                    <div class="field">
                      <p class="control">
                        <input class="input" type="text">
                      </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="column is-2 has-text-right">
            <button class="button is-dark px-30"><b>Search</b></button>
        </div>
    </div>
    <div class="columns is-multiline">
        <div class="column is-4">
            <div class="field is-horizontal">
                <div class="field-label is-normal">
                    <label class="label">Make</label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <div class="select is-fullwidth">
                            <select name="hh">
                                <?php $__currentLoopData = $sidebar->make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->slug); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="column is-4">
            <div class="field is-horizontal">
                <div class="field-label is-normal">
                    <label class="label">Model</label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <div class="select is-fullwidth">
                            <select name="hh">
                                <?php $__currentLoopData = $sidebar->make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->slug); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="column is-4">
            <div class="field is-horizontal">
                <div class="field-label is-normal">
                    <label class="label">Year</label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <div class="select">
                            <select name="hh">
                                <?php $__currentLoopData = $sidebar->make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->slug); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="select">
                            <select name="hh">
                                <?php $__currentLoopData = $sidebar->make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->slug); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="column is-4">
            <div class="field is-horizontal">
                <div class="field-label is-normal">
                    <label class="label">Type</label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <div class="select is-fullwidth">
                            <select name="hh">
                                <?php $__currentLoopData = $sidebar->make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->slug); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="column is-4">
            <div class="field is-horizontal">
                <div class="field-label is-normal">
                    <label class="label">Stearing</label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <div class="select is-fullwidth">
                            <select name="hh">
                                <?php $__currentLoopData = $sidebar->make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->slug); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="column is-4">
            <div class="field is-horizontal">
                <div class="field-label is-normal">
                    <label class="label">Deals</label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <div class="select is-fullwidth">
                            <select name="hh">
                                <?php $__currentLoopData = $sidebar->make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->slug); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>