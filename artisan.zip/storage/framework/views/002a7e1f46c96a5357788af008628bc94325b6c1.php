<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="site-url" content="<?php echo e(url('/')); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?> <?php echo e(app()->version()); ?></title>

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <div id="helper">
            <div class="spinner" v-if="is_spining">
                <span class="icon">
                    <i class="fa fa-refresh fa-spin fa-3x"></i><br/>
                    Processing
                </span>
            </div>
        </div>
        <div id="app" class="container">
            <header class="app_header">
                <a class="navbar-item" href="<?php echo e(url('/')); ?>">
                  <img src="<?php echo e(asset('img/logo.png')); ?>" width="112" height="28">
                </a>
                <?php echo $__env->make('layouts.header_backend_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </header>
            <div class="wraper">
            <?php echo $__env->yieldContent('content'); ?>
            </div>
            <footer class="app_footer mt-20">
                <?php echo $__env->make('layouts.footer_contacts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </footer>
        </div>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
