<?php $__env->startComponent('mail::message'); ?>
# Price Quotation
### (Estimate)

## <?php echo e($vehicle->name); ?>

### <?php echo e($country->name); ?>

__<?php echo e($port->name); ?>(port)__

<?php $__env->startComponent('mail::button', ['url' => route('single', ['id'=>$vehicle->id, 'country_id'=>$country->id, 'port_id'=>$port->id]).'#step']); ?>
Show on website
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::table'); ?>
| Vehicle Price | <?php echo e($vehicle->price); ?> 		|
| ------------- |:-------------:|
|  Insurance    | <?php echo e($port->insurance); ?> 		|
|  inspection   | <?php echo e($port->inspection); ?> 	|
|  certificate  | <?php echo e($port->certificate); ?> 	|
|  warranty     | <?php echo e($port->warranty); ?> 		|
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('mail::table'); ?>
| 				| 							|
| ------------- |:-------------:|
|  __Total__	|__<?php echo e($vehicle->price+$port->insurance+$port->inspection+$port->certificate+$port->warranty); ?>__ 	|
<?php echo $__env->renderComponent(); ?>

## Applient's Info
### <?php echo e($user->name); ?>

<?php echo e($user->email); ?>

<?php echo e($user->phone); ?>

<?php echo e($user->city); ?>

<?php echo e($user->address); ?>


__Thanks,__<br>
###MCI Corporation
__01986066157__

<?php echo $__env->renderComponent(); ?>
