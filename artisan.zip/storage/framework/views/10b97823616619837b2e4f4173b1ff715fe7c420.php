
<div class="sidebar columns is-multiline">

    <!-- Make Widzert -->
    <?php $__currentLoopData = $sidebar->taxonomy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="widzert mb-10 column is-6">
        <h5 class="title is-5 py-2"><?php echo e($tax->name); ?></h5>
        <div>
            <?php $__currentLoopData = $sidebar->{$tax->slug}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="checkbox">
                <input name="taxonomy[]" value="<?php echo e($data->id); ?>" type="checkbox" <?php echo e(in_array($data->id, $taxonomy_meta_selected)?'checked':''); ?>>
                <?php echo e($data->name); ?>

            </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Make Widzert -->
	<div class="widzert mb-10 column is-6">
		<h5 class="title is-5 py-2">Feature</h5>
		<div>
			<?php $__currentLoopData = $feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<label class="checkbox">
				<input name="feature[]" value="<?php echo e($data->id); ?>" type="checkbox" <?php echo e(in_array($data->id, $feature_selected)?'checked':''); ?>>
				<?php echo e($data->name); ?>

			</label>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
    
</div>