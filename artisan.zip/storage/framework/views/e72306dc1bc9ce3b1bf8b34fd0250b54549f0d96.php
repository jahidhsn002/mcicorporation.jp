<section class="column is-12">
    <!-- Step 01 -->
    <?php if(count($ports)<=0): ?>
        <div class="card" id="step">
            <div class="card-content">
                <form action="<?php echo e(route('archive')); ?>" method="GET">
                <div class="columns">
                    <div class="column is-5">
                        <p class="card-header-title">TOTAL PRICE CALCULATOR</p>
                        <div>
                            Total Price calculator will estimate the total price of the vehicle(s) based on your shipping destination port and other preferences. <br/>
                            Note: In some cases the total price cannot be estimated.
                        </div>
                    </div>
                    <div class="column is-5">
                        <div class="field">
                            <label class="label">Choose Final Country*</label>
                            <div class="control">
                                <div class="select">
                                  <select name="country_id">
                                    <option>Select</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="column is-2">
                        <div class="field">
                            <button class="button is-dark px-30 is-large mt-20" type="submit">Calculate</button>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <?php if(count($ports)>0): ?>
        <div class="card" id="step">
            <div class="card-content">
                <form action="<?php echo e(route('archive')); ?>" method="GET">
                <div class="columns">
                    <div class="column is-5">
                        <p class="card-header-title">TOTAL PRICE CALCULATOR</p>
                        <div>
                            Total Price calculator will estimate the total price of the vehicle(s) based on your shipping destination port and other preferences. <br/>
                            Note: In some cases the total price cannot be estimated.
                        </div>
                    </div>
                    <div class="column is-5">
                        <div class="field">
                            <label class="label">Choose Country*</label>
                            <div class="control">
                                <div class="select">
                                  <select name="country_id">
                                    <option>Select</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>"
                                        <?php if(isset($_REQUEST['country_id'])): ?>
                                            <?php if($_REQUEST['country_id']==$country->id): ?>
                                                selected
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    ><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </div>
                            </div>
                        </div>
                        <div class="field">
                            <label class="label">Choose Port*</label>
                            <div class="control">
                                <div class="select">
                                  <select name="port_id">
                                    <option>Select</option>
                                    <?php $__currentLoopData = $ports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($port->id); ?>"
                                        <?php if(isset($_REQUEST['port_id'])): ?>
                                            <?php if($_REQUEST['port_id']==$port->id): ?>
                                                selected
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    ><?php echo e($port->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="column is-2">
                        <div class="field has-text-left">
                            <button class="button is-dark px-30 is-large mt-20" type="submit">Calculate</button>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
<?php endif; ?>
</section>