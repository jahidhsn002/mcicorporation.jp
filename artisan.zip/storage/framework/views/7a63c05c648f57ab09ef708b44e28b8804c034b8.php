
<div class="sidebar">

	<!-- Make Widzert -->
	<div class="widzert">
		<h5 class="title is-5 py-5">Shop By Make</h5>
		<ul>
			<?php $__currentLoopData = $sidebar->make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="<?php echo e(route('archive', ['taxonomy[]' => $data->id])); ?>">
					<?php if($data->logo): ?>
                        <?php $__currentLoopData = json_decode($data->logo); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset($link)); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <img src="<?php echo e(asset('img/make_logo.jpg')); ?>">
                    <?php endif; ?>
					<?php echo e($data->name); ?>

				</a>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>

	<!-- Make Body Type -->
	<div class="widzert">
		<h5 class="title is-5 py-5">Shop By Type</h5>
		<ul>
			<?php $__currentLoopData = $sidebar->{'body-type'}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="<?php echo e(route('archive', ['taxonomy[]' => $data->id])); ?>">
					<?php if($data->logo): ?>
                        <?php $__currentLoopData = json_decode($data->logo); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset($link)); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <img src="<?php echo e(asset('img/body_type_logo.jpg')); ?>">
                    <?php endif; ?>
					<?php echo e($data->name); ?>

				</a>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>

	<!-- Make Drivetrain -->
	<div class="widzert">
		<h5 class="title is-5 py-5">Other Categories</h5>
		<ul>
			<?php $__currentLoopData = $sidebar->drivetrain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="<?php echo e(route('archive', ['taxonomy[]' => $data->id])); ?>">
					<img src="img/drivetrain_logo.jpg">
					<?php echo e($data->name); ?>

				</a>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
</div>