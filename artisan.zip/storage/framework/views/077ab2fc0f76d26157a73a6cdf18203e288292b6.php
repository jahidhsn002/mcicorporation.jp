<?php $__env->startSection('content'); ?>

	<h3 class="title is-4 mb-15"><?php echo e($taxonomy->name); ?> Metas</h3>
	
	<div class="box mb-20">
		
		<table class="table" width="100%">
			<tr class="columns">
				<th class="column is-2">Name</th>
				<th class="column is-2">Insurance</th>
				<th class="column is-2">Inspection</th>
				<th class="column is-2">Certificate</th>
				<th class="column is-2">Warranty</th>
				<th class="column is-2 has-text-right">Options</th>
			</tr>
		</table>

		<form action="<?php echo e(route('taxonomy_taxonomy_meta_save')); ?>" method="POST">
    		<input type="hidden" name="_method" value="PUT">
    		<input type="hidden" name="taxonomy_id" value="<?php echo e($taxonomy->id); ?>">
    		<?php echo e(csrf_field()); ?>

			<table class="table" width="100%">
	    		<tr class="columns">
					<td class="column is-6">
						<input type="text" class="input" name="name">
					</td>
					<td class="column is-6 has-text-right">
						<button type="submit" class="button is-success">Add New</button>
					</td>
				</tr>
	    		
			</table>
		</form>

		<?php $__currentLoopData = $taxonomy_metas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxonomy_meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<form action="<?php echo e(route('taxonomy_taxonomy_meta_save')); ?>" method="POST">
    		<input type="hidden" name="_method" value="PUT">
    		<input type="hidden" name="taxonomy_id" value="<?php echo e($taxonomy->id); ?>">
    		<input type="hidden" name="id" value="<?php echo e($taxonomy_meta->id); ?>">
    		<?php echo e(csrf_field()); ?>

			<table class="table" width="100%">
	    		<tr class="columns">
					<td class="column is-6">
						<input type="text" class="input" name="name" value="<?php echo e($taxonomy_meta->name); ?>">
					</td>
					<td class="column is-6 has-text-right">
						<button type="submit" class="button is-dark">Save</button>
						<a href="#" class="button is-dark">Delete</a>
					</td>
				</tr>
	    		
			</table>
		</form>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

    <div class="has-text-centered">
    	<a href="#">Back to Dashboard</a>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>