<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('password_save')); ?>" method="POST" class="pa-20">
    	
    	<?php echo e(csrf_field()); ?> <input type="hidden" name="_method" value="PUT">
	
	<h3 class="title is-4 mb-5">Wishlists</h3>
	<div>
		List of your favorite vehicles. You will be notified by email when vehicles' status changes to "Marked Down Prices".
	</div>
	<hr class="my-5" />
	<div class="mt-15">
		<?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<div class="py-5">
    		<a href="<?php echo e(route('wishlist_delete', ['id'=> $wishlist->id])); ?>" class="delete is-pulled-right"></a>
    		<?php $__currentLoopData = $wishlist->taxonomies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxonomy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<a href="<?php echo e(route('archive', [
    					'taxonomy' => $wishlist->taxonomy
    				])); ?>"><?php echo e($taxonomy->name); ?></a> / 
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		<?php if($wishlist->taxonomies == '[]'): ?>
    			No Taxonomy
    		<?php endif; ?>
	    </div>
		<hr class="my-2" />
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="has-text-centered">
    	<a href="#">Back to Dashboard</a>
    </div>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>