<div class="container social pb-15">
	<div class="columns">
		<div class="column is-2">
			<a href="https://bulma.io">
              <img src="<?php echo e(asset('img/logo.png')); ?>" width="112" height="28">
            </a>
		</div>
		<div class="column is-2">
			4-6-1 Fuda Chofu-City, Tokyo
			182-0024 Japan
			Tel : +81 42 440 3440
			FAX : +81 42 440 3450
			Email : top@beforward.jp
		</div>
		<div class="column is-8 has-text-right pt-25 social_icon">
			<a class="mr-5" href="#">
				<i class="fa fa-facebook-square fa-3x"></i>
			</a>
			<a class="mr-5" href="#">
				<i class="fa fa-facebook-square fa-3x"></i>
			</a>
			<a class="mr-5" href="#">
				<i class="fa fa-facebook-square fa-3x"></i>
			</a>
			<a class="mr-5" href="#">
				<i class="fa fa-facebook-square fa-3x"></i>
			</a>
			<a class="mr-5" href="#">
				<i class="fa fa-facebook-square fa-3x"></i>
			</a>
		</div>
	</div>
</div>
