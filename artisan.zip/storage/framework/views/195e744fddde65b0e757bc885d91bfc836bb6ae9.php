<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('vehicle_save')); ?>" method="POST">

    <div class="columns is-marginless is-centered">

        <div class="column is-6">
            <?php echo $__env->make('backend.vehicle_right_option', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="column is-6">

            <div class="card">
                <header class="card-header">
                    <p class="card-header-title">
                        <?php echo e($vehicle?'Edit '.$vehicle->name:'New Vehicle'); ?>

                    </p>
                    <button class="button is-success mr-2 mt-5 px-20" type="submit">Save</button>
                    <?php if($vehicle): ?>
                    <a class="button is-danger mr-5 mt-5 px-20" href="<?php echo e(route('vehicle_delete', ['id'=> $vehicle->id])); ?>">Delete</a>
                    <?php endif; ?>
                </header>

                <div class="card-content">

                    <div class="columns is-multiline">

                        <input type="hidden" name="_method" value="PUT">
                        <input type="hidden" name="id" value="<?php echo e($id); ?>">

                        <?php echo e(csrf_field()); ?>


                        

                        <div class="column is-6">

                            <div class="field">
                              <label class="label">Name</label>
                              <div class="control">
                                <input class="input" type="text" name="name" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->name); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Ref No</label>
                              <div class="control">
                                <input class="input" type="text" name="ref_no" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->ref_no); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Actual Price</label>
                              <div class="control">
                                <input class="input" type="number" step="any" name="actual_price" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->actual_price); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Price</label>
                              <div class="control">
                                <input class="input" type="number" step="any" name="price" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->price); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Manufacture Date</label>
                              <div class="control">
                                <input class="input" type="text" name="manufacture" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->manufacture); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Model Code</label>
                              <div class="control">
                                <input class="input" type="text" name="model_code" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->model_code); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Engine</label>
                              <div class="control">
                                <input class="input" type="number" step="any" name="engine" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->engine); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Mileage</label>
                              <div class="control">
                                <input class="input" type="number" step="any" name="mileage" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->mileage); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>






                            <div class="field">
                              <label class="label">Chassis</label>
                              <div class="control">
                                <input class="input" type="text" name="chassis" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->chassis); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Engine Code</label>
                              <div class="control">
                                <input class="input" type="text" name="engine_code" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->engine_code); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Seats</label>
                              <div class="control">
                                <input class="input" type="text" name="seats" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->seats); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Dors</label>
                              <div class="control">
                                <input class="input" type="text" name="dors" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->dors); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Dimension</label>
                              <div class="control">
                                <input class="input" type="text" name="dimension" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->dimension); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">M3</label>
                              <div class="control">
                                <input class="input" type="text" name="m3" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->m3); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Weight</label>
                              <div class="control">
                                <input class="input" type="text" name="weight" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->weight); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                            <div class="field">
                              <label class="label">Registration</label>
                              <div class="control">
                                <input class="input" type="text" name="registration" 
                                    <?php if($vehicle): ?> value="<?php echo e($vehicle->registration); ?>" <?php endif; ?>
                                >
                              </div>
                            </div>

                        </div>

                        <div class="column is-6">

                            <div class="field">
                                <label class="label">Thumbnail</label>
                                <div class="control">
                                    <field-image
                                        name="thumbnail"
                                        <?php if(isset($vehicle->thumbnail)): ?> :value="<?php echo e($vehicle->thumbnail); ?>" <?php endif; ?>
                                    ></field-image>
                                </div>
                            </div>

                            <div class="field">
                                <label class="label">Gallery</label>
                                <div class="control">
                                    <field-image
                                        name="gallery" multiple
                                        <?php if(isset($vehicle->gallery)): ?> :value="<?php echo e($vehicle->gallery); ?>" <?php endif; ?>
                                    ></field-image>
                                </div>
                            </div>

                        </div>

                        <div class="column is-12 has-text-centered">

                            <button class="button is-success mr-2 mt-5 px-20" type="submit">Save</button>
                            <button class="button is-warning mr-2 mt-5 px-20" type="reset">Reset</button>
                            <button class="button is-danger mr-5 mt-5 px-20" type="reset">Delete</button>

                        </div>

                    </div>
                </div>


                

            </div>
        </div>
        
    </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>