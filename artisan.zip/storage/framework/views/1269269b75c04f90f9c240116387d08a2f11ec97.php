<?php $__env->startSection('content'); ?>

    <div class="columns is-marginless is-centered mt-100 mb-100">
        <div class="column is-5">
            <div class="card">
                <header class="card-header">
                    <p class="card-header-title">Reset Password</p>
                </header>

                <div class="card-content">
                    <?php if(session('status')): ?>
                        <div class="notification">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form class="forgot-password-form" method="POST" action="<?php echo e(route('password.email')); ?>">

                        <?php echo e(csrf_field()); ?>


                        <div class="field is-horizontal">
                            <div class="field-label">
                                <label class="label">E-Mail Address</label>
                            </div>

                            <div class="field-body">
                                <div class="field">
                                    <p class="control">
                                        <input class="input" id="email" type="email" name="email"
                                               value="<?php echo e(old('email')); ?>" required autofocus>
                                    </p>

                                    <?php if($errors->has('email')): ?>
                                        <p class="help is-danger">
                                            <?php echo e($errors->first('email')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="field is-horizontal">
                            <div class="field-label"></div>

                            <div class="field-body">
                                <div class="field is-grouped">
                                    <div class="control">
                                        <button type="submit" class="button is-primary">Send Password Reset Link
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>