<nav class="navbar is-dark has-shadow top_navbar">
        <div class="navbar-brand">
            <div class="navbar-burger burger" data-target="navMenu">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>

        <div class="navbar-menu" id="navMenu">
            <div class="navbar-start">
                <a class="navbar-item " href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                <!--<a class="navbar-item " href="#">Inquires</a>-->
                <a class="navbar-item " href="<?php echo e(route('favorite')); ?>">Favorite</a>
                <a class="navbar-item " href="<?php echo e(route('wishlist')); ?>">Wish List</a>
                <div class="navbar-item has-dropdown is-hoverable">
                    <a class="navbar-link" href="#">
                      Account Info
                    </a>
                    <div class="navbar-dropdown">
                        <a class="navbar-item py-2" href="<?php echo e(route('account')); ?>">Account Information</a>
                        <a class="navbar-item py-2" href="<?php echo e(route('language')); ?>">Language Preferences</a>
                        <a class="navbar-item py-2" href="<?php echo e(route('password')); ?>">Update your Password</a>
                    </div>
                </div>
                <?php if(Auth::user()->is_admin): ?>
                <div class="navbar-item has-dropdown is-hoverable">
                    <a class="navbar-link" href="#">
                      Admin
                    </a>
                    <div class="navbar-dropdown">
                         <a class="navbar-item py-2" href="<?php echo e(route('new_vehicle')); ?>">New Car</a>
                         <a class="navbar-item py-2" href="<?php echo e(route('country')); ?>">Country &amp; Port</a>
                         <a class="navbar-item py-2" href="<?php echo e(route('taxonomy')); ?>">Taxonomy &amp; Metas</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="navbar-end">
                <div class="navbar-item has-dropdown is-hoverable is-mega">
                    <a class="navbar-link " href="#">
                        <div class="has-text-centered">
                            Browse Stocks
                        </div>
                    </a>
                    <div class="navbar-dropdown is-right">
                        <div class="container is-fluid">
                            <div class="columns is-gapless">
                                <div class="column">
                                    <div class="saperater">
                                    <?php $__currentLoopData = $sidebar->taxonomy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key == 1 || $key == 2 || $key == 5 || $key == 16 || $key == 20): ?>
                                    </div>
                                </div>
                                <div class="column">
                                    <div class="saperater">
                                        <?php endif; ?>
                                        <h5 class="title is-5 pl-10 py-0 my-10"><?php echo e($tax->name); ?></h5>
                                        <?php $__currentLoopData = $sidebar->{$tax->slug}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="navbar-item py-2" href="<?php echo e(route('archive', ['taxonomy[]'=>$data->id])); ?>"><?php echo e($data->name); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</nav>