<?php $__env->startSection('content'); ?>

    <h3 class="title is-4 mb-0 mt-30">Dashboard</h3>
    <div class="columns is-marginless is-centered">
        <div class="column is-3 is-offset-3">
        	<h3 class="title is-5">Inquiries</h3>
        	<hr/>
        	<div class="">
                <a class="box px-20 py-5 mb-0" href="<?php echo e(route('wishlist')); ?>">Wish List</a>
                <a class="box px-20 py-5 mb-0" href="<?php echo e(route('favorite')); ?>">Favorite</a>
            </div>
        </div>

        <div class="column is-3">
        	<h3 class="title is-5">Account Info</h3>
        	<hr/>
        	<div class="">
                <a class="box px-20 py-5 mb-0" href="<?php echo e(route('account')); ?>">Account Information</a>
                <a class="box px-20 py-5 mb-0" href="<?php echo e(route('language')); ?>">Language Preferences</a>
                <a class="box px-20 py-5 mb-0" href="<?php echo e(route('password')); ?>">Update your Password</a>
            </div>
        </div>
        <div class="column is-3"></div>
        
    </div>
    <div class="columns is-multiline mx-100">
        <div class="column is-12">
            <h4 class="title is-4 mb-5">New Arrival</h4>
            <div class="a-line">
                <div></div>
            </div>
        </div>

        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="column is-2">
            <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                <?php if($vehicle->thumbnail): ?>
                    <?php $__currentLoopData = json_decode($vehicle->thumbnail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure>
                        <img src="<?php echo e(asset($link)); ?>" width="100%">
                    </figure>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <img src="<?php echo e(asset('img/car.jpg')); ?>" width="100%">
                <?php endif; ?>
                <h3 class="title is-5 ma-0"><?php echo e($vehicle->name); ?></h3>
                <div>Vehicle Price:</div>
                <h3 class="title is-6 ma-0"><?php echo e($vehicle->price); ?></h3>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>