<?php $__env->startSection('content'); ?>
    <div class="container page_single">
        <div class="columns">
            <div class="column is-8 is-offset-2">
                <div class="columns my-0 is-multiline">
                    <div class="column is-6">
                        <?php if($vehicle->thumbnail): ?>
                            <?php $__currentLoopData = json_decode($vehicle->thumbnail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <figure>
                                <img src="<?php echo e(asset($link)); ?>" data-action="zoom" class="joomable">
                            </figure>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <img src="<?php echo e(asset('img/car_1.jpg')); ?>">
                        <?php endif; ?>
                        <div class="gullery_thumbnail columns my-0 is-multiline">
                            <?php if($vehicle->gallery): ?>
                                <?php $__currentLoopData = json_decode($vehicle->gallery); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <figure class="column is-3">
                                    <img src="<?php echo e(asset($link)); ?>" data-action="zoom" class="joomable">
                                </figure>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <figure class="column is-3">
                                    <img src="<?php echo e(asset('img/car_1.jpg')); ?>">
                                </figure>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="column is-6">
                        <h3 class="title is-4"><?php echo e($vehicle->name); ?></h3>
                        <div class="price columns">
                            <div class="column is-8">
                                
                                <h4 class="title is-5 box mb-10 py-10 has-text-right">
                                    <?php if($vehicle->actual_price): ?>
                                        <del>Actual price: <span class="has-text-success"><?php echo e($vehicle->actual_price); ?></span></del> <br/>
                                    <?php endif; ?>
                                    Current price: <span class="has-text-success"><?php echo e($vehicle->price); ?></span> <br/>
                                    <?php if($vehicle->actual_price): ?>
                                        You Save: <span class="has-text-success"><?php echo e($vehicle->actual_price - $vehicle->price); ?></span>
                                    <?php endif; ?>
                                </h4>
                            </div>
                            <div class="column">
                                <?php if(Auth::check()): ?>
                                    <?php if(Auth::user()->is_admin): ?>
                                    <a class="button is-warning is-small mb-2" style="width:100%" href="<?php echo e(route('save_vehicle', ['id'=>$vehicle->id])); ?>">Edit</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <a href="<?php echo e(route('favorite_save', ['vehicle_id' => $vehicle->id])); ?>" class="button is-warning mb-2" style="width:100%">Favorite</a> <br/>
                                <button class="button is-warning" style="width:100%">Print</button>
                            </div>
                        </div>
                        <a href="#step" class="button is-large is-warning has-text-uppercase mb-10">Get a price quote now</a>
                        <div class="card">
                            <header class="card-header">
                                <p class="card-header-title">Specs</p>
                            </header>
                            <div class="card-content">
                                <div class="columns is-gapless">
                                    <div class="column is-6 pa-0">
                                        <table class="table mb-5" width="100%">
                                            <tr>
                                                <th>Ref No</th>
                                                <td><?php echo e($vehicle->ref_no); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Engine Size</th>
                                                <td><?php echo e($vehicle->engine); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Model Code</th>
                                                <td><?php echo e($vehicle->model_code); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Mileage</th>
                                                <td><?php echo e($vehicle->mileage); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Chassis</th>
                                                <td><?php echo e($vehicle->chassis); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Engine Code</th>
                                                <td><?php echo e($vehicle->engine_code); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Seats</th>
                                                <td><?php echo e($vehicle->seats); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Dors</th>
                                                <td><?php echo e($vehicle->dors); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Simension</th>
                                                <td><?php echo e($vehicle->dimension); ?></td>
                                            </tr>
                                            <tr>
                                                <th>M3</th>
                                                <td><?php echo e($vehicle->m3); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Weight</th>
                                                <td><?php echo e($vehicle->weight); ?></td>
                                            </tr>
                                            <tr>
                                                <th class="has-text-success">Manufacture <br/> Year/month</th>
                                                <td><?php echo e($vehicle->manufacture); ?></td>
                                            </tr>
                                            <tr>
                                                <th class="has-text-danger">Registration <br/> Year/month</th>
                                                <td><?php echo e($vehicle->registration); ?></td>
                                            </tr>
                                        </table>
                                        <div class="pa-5">
                                            <small>
                                            <small class="has-text-success">
                                                * [Manufacture Year/month] is provided by database provider. 
                                                BE FORWARD shall not be responsible for any loss, damages
                                                and troubles caused by this information.
                                            </small>
                                            </small>
                                            <br>
                                            <small>
                                            <small class="has-text-danger">
                                                * [Registration Year/month] is a registration date in Japan.
                                            </small>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="column is-6 pa-0">
                                        <table class="table mb-5" width="100%">
                                            <?php $__currentLoopData = $vehicle->taxonomies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax_meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th><?php echo e($tax_meta->taxonomy->name); ?></th>
                                                <td><?php echo e($tax_meta->name); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card feature">
                            <h3 class="title is-4 px-10 pt-15 pb-0 mb-0">Standard features</h3>
                            <div class="card-content">
                                <div class="columns is-multiline is-gapless">
                                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="column is-3 box <?php echo e(in_array($feat->id, $feature_selected)?'selected':''); ?>">
                                        <div class="pa-10"><?php echo e($feat->name); ?></div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-8 is-offset-2">
                    
                    <!-- Step 01 -->
                    <?php if(count($ports)<=0): ?>
                    <div class="card" id="step">
                        <header class="card-header">
                            <p class="card-header-title">Step 1. CHOOSE YOUR DELIVERY OPTIONS</p>
                        </header>
                        <div class="card-content">
                            <form action="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>#step" method="GET">
                                <div class="field">
                                    <label class="label">Choose Final Country*</label>
                                    <div class="control">
                                        <div class="select">
                                          <select name="country_id">
                                            <option>Select</option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="field">
                                    <button class="button is-dark px-50" type="submit">Next</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endif; ?>


                    <?php if(count($ports)>0): ?>
                    <div class="card" id="step">
                        <header class="card-header">
                            <p class="card-header-title">Step 2. CHOOSE YOUR DELIVERY OPTIONS</p>
                        </header>
                        <div class="card-content">
                            <form action="<?php echo e(route('inquary_email')); ?>#sep-1" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="patch">
                                <input type="hidden" name="vehicle_id" value="<?php echo e($vehicle->id); ?>">
                                <div class="field">
                                    <label class="label">Choose Final Country*</label>
                                    <div class="control">
                                        <div class="select">
                                          <select name="country_id">
                                            <option>Select</option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"
                                                <?php if(isset($_REQUEST['country_id'])): ?>
                                                    <?php if($_REQUEST['country_id']==$country->id): ?>
                                                        selected
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            ><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="field">
                                    <table class="table" width="100%">
                                        <tr>
                                            <th>Choose</th>
                                            <th>Port</th>
                                            <th>Destination</th>
                                            <th>Cost</th>
                                            <th>Total</th>
                                        </tr>
                                        <?php $__currentLoopData = $ports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="control">
                                                    <label class="radio">
                                                      <input value="<?php echo e($port->id); ?>" type="radio" name="port_id" 
                                                        <?php if(isset($_REQUEST['port_id'])): ?>
                                                            <?php if($_REQUEST['port_id']==$port->id): ?>
                                                                checked
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                      >
                                                    </label>
                                                </div>
                                            </td>
                                            <td><?php echo e($port->name); ?></td>
                                            <td><?php echo e($port->name); ?> (port)</td>
                                            <td><?php echo e($port->insurance+$port->inspection+$port->certificate+$port->warranty); ?></td>
                                            <td><?php echo e($vehicle->price+$port->insurance+$port->inspection+$port->certificate+$port->warranty); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                                <div class="field">
                                    <button class="button is-dark px-50" type="submit">Get Quote</button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="card mt-15">
                        <header class="card-header">
                            <p class="card-header-title">Step 3. YOUR DETAILS</p>
                        </header>
                        <div class="card-content">
                            <div class="columns">
                                <div class="column is-6">
                                    <div class="field">
                                        <label class="label">Name*</label>
                                        <div class="control">
                                            <input class="input" type="text" name="name" 
                                                <?php if(Auth::check()): ?>
                                                value="<?php echo e(Auth::user()->name); ?>"
                                                <?php endif; ?>
                                            >
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Email*</label>
                                        <div class="control">
                                            <input class="input" type="email" name="email" 
                                                <?php if(Auth::check()): ?>
                                                value="<?php echo e(Auth::user()->email); ?>"
                                                <?php endif; ?>
                                            >
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Phone*</label>
                                        <div class="control">
                                            <input class="input" type="text" name="phone" 
                                                <?php if(Auth::check()): ?>
                                                value="<?php echo e(Auth::user()->phone); ?>"
                                                <?php endif; ?>
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="column is-6">
                                    <div class="field">
                                        <label class="label">City*</label>
                                        <div class="control">
                                            <input class="input" type="text" name="city" 
                                                <?php if(Auth::check()): ?>
                                                value="<?php echo e(Auth::user()->city); ?>"
                                                <?php endif; ?>
                                            >
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Address*</label>
                                        <div class="control">
                                            <input class="input" type="text" name="address" 
                                                <?php if(Auth::check()): ?>
                                                value="<?php echo e(Auth::user()->address); ?>"
                                                <?php endif; ?>
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endif; ?>


                    <div class="card mt-15">
                        <header class="card-header">
                            <p class="card-header-title">HOW TO GET A PROFORMA INVOICE</p>
                        </header>
                        <div class="card-content">
                            <h5 class="title is-6 mb-10 mt-0">To get Proforma Invoice, please do the followings:</h5>
                            <div class="pl-15">
                                <ol>
                                    <li>Fill out the required fields above and click the Inquiry button.</li>
                                    <li>You will receive a quotation from BE FORWARD via email.</li>
                                    <li>Reply to the email if you accept the quotation.</li>
                                    <li>We will issue a Proforma Invoice once you completed the steps above.</li>
                                </ol>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>