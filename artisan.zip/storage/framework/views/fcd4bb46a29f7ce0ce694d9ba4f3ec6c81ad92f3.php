<?php $__env->startSection('content'); ?>
    <div class="container archive">
        <div class="columns is- is-marginless is-centered">
            <div class="column is-2">
                <?php echo $__env->make('layouts.left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="column is-10">
                <div class="columns is-multiline">
                    
                    <form action="<?php echo e(route('archive')); ?>" method="GET">
                    
                        <?php echo $__env->make('layouts.archive_search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    </form>

                    <div class="column is-12 data_table">
                        <table class="table is-stripd" width="100%">
                            <tr>
                                <th>Image</th>
                                <th>Ref No.</th>
                                <th>Make/Model</th>
                                <th>Year</th>
                                <th>Engine</th>
                                <th>Milage</th>
                                <th>Steering Trans</th>
                                <th>Vehicle Price</th>
                                <th>Total Price</th>
                            </tr>
                            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <?php if($vehicle->thumbnail): ?>
                                            <?php $__currentLoopData = json_decode($vehicle->thumbnail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e(asset($link)); ?>" style="height: 100px">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('img/car.jpg')); ?>" style="height: 100px">
                                        <?php endif; ?>
                                    </a>
                                </td>
                                <td class="has-text-centered">
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <?php echo e($vehicle->ref_no); ?>

                                    </a> <br/>
                                    <a class="button mt-5" href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <i class="fa fa-heart"></i> &nbsp; Favorites
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <?php echo e($vehicle->name); ?> <br/>
                                        <?php if(isset($vehicle->model_code)): ?> ( <span class="mt-5"><?php echo e($vehicle->model_code); ?></span> ) <?php endif; ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <?php echo e($vehicle->manufacture); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <?php echo e($vehicle->engine); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <?php echo e($vehicle->mileage); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <?php echo e($vehicle->ref_no); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <?php echo e($vehicle->price); ?>

                                    </a>
                                </td>
                                <td class="has-text-centered">
                                    <a href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <?php echo e($vehicle->price); ?>

                                    </a> <br/>
                                    <button class="button mt-5 is-warning" href="<?php echo e(route('single', ['id'=> $vehicle->id])); ?>">
                                        <i class="fa fa-envelope"></i> &nbsp; Inquiry
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>