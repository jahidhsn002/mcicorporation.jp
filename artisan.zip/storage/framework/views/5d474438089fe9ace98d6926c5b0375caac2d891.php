
<div class="sidebar">
	
	<!-- Add Widzert -->
	<div class="widzert">
		<a href="#">
			<img src="img/add_left.png" width="100%">
		</a>
	</div>

	<!-- Add Widzert -->
	<div class="widzert">
		<a href="#">
			<img src="img/add_left.png" width="100%">
		</a>
	</div>

	<!-- Make Body Type -->
	<div class="widzert">
		<h5 class="title is-5 py-5">Latest Collection</h5>
		<ul>
			<?php $__currentLoopData = $sidebar->new_cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="<?php echo e(route('archive', ['taxonomy[]' => $data->id])); ?>">
					<?php if($data->thumbnail): ?>
                        <?php $__currentLoopData = json_decode($data->thumbnail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset($link)); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <img src="<?php echo e(asset('img/body_type_logo.jpg')); ?>">
                    <?php endif; ?>
					<?php echo e($data->name); ?>

				</a>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>

</div>